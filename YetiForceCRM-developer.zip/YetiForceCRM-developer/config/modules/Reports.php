<?php
/**
 * Reports module config
 * @package YetiForce.Config
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 2.0 (licenses/License.html or yetiforce.com)
 */
return[
	// Maximum number of column in reports
	'MAX_REPORT_COLUMN' => 50, // Boolean
];
