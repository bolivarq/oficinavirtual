<?php
return [
	'appVersion' => '4.2.220',
	'patchVersion' => '2017.09.20',
	'lib_mPDF' => '0.0.2',
	'lib_roundcube' => '0.0.34',
	'lib_PHPExcel' => '0.0.0',
	'lib_gantt' => '0.0.1',
];
