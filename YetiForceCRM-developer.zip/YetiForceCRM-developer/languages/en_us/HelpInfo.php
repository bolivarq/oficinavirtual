<?php
/**
 * HelpInfo english translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 2.0 (licenses/License.html or yetiforce.com)
 */
$languageStrings = [
	'Announcements|FL_INTERVAL' => 'Frequency of reminders in days, if a user did not review changes. If the field remains empty the reminder will not be displayed again.',
	'Accounts|Account Name' => 'This field is intended for company name',
];
