<?php
/**
 * Oss mail german translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 2.0 (licenses/License.html or yetiforce.com)
 */
$languageStrings = [
	'OSSMail' => 'Meine E-Mailbox',
	'ERR_NO_MODULE_IS_INACTIVE' => '"Mein E-Mailbox" Modul ist inaktiv, bitte vor der Konfiguration aktivieren.'
];

$jsLanguageStrings = [
	'JS_ERROR_EMPTY' => 'Alle Felder müssen ausgefüllt werden',
];
